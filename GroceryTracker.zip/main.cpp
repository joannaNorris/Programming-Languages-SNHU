#include "main.h"
#include <iostream>
#include <map> 
#include <fstream> 
#include <string> 
#include <sstream>

using namespace std;


int main() {

	//open the text file
	std::ifstream inputFile("CS210_Project_Three_Input_File.txt");

    //check if the file is opened successfully
    if (!inputFile) {
        std::cerr << "Error opening file." << std::endl;
        return 1;
    }

    std::map<string, int> wordFreqMap;

    std::string word; //file is read word by word
    while (inputFile >> word) {
        wordFreqMap[word]++; //frequency is updated
    }
    
    inputFile.close(); //close the text file

    //print the menu
    cout << "Menu Options:" << endl;
    cout << "Press 1 to view an item's frequency." << endl;
    cout << "Press 2 to view the frequency of all items purchased." << endl;
    cout << "Press 3 to view the frequency of all items purchased in the form of a histogram." << endl;
    cout << "Press 4 to exit." << endl;

    int userInput;
    cin >> userInput;//input user's input
    
    string itemNeeded;
    std::map<std::string, int>::iterator it;
    
    switch (userInput) {//chooses between options from user's input
        case 1:
            cout << "Which item would you like the frequency of?" << endl;
            
            cin >> itemNeeded;

            it = wordFreqMap.find(itemNeeded); //search for the item needed

            if (it != wordFreqMap.end()) {
                std::cout << it->first << " " << it->second << std::endl;
            }
            break;
        case 2:
            //print word frequencies
            std::cout << "Item frequencies:" << std::endl;
            for (const auto& pair : wordFreqMap) {
                std::cout << pair.first << " " << pair.second << std::endl;
            }
            break;
        case 3:
            std::cout << "Item frequencies:" << std::endl;
            for (const auto& pair : wordFreqMap) {
                std::cout << pair.first << " ";
                for (int i = 0; i < pair.second; i++) {
                    std::cout << "*"; //print astericks for each occurence
                }
                std::cout << std::endl;
            }
            break;
        case 4:
            return 0;
        default:
            std::cout << "Invalid input. Please enter a valid option." << std::endl;
            break;
    }
    

    return 0;
}