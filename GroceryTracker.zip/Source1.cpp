#include <iostream>
#include <map>
#include <string>
#include <fstream>

using namespace std;

int main() {
	ifstream inFS;

	inFS.open("CS210_Project_Three_Input_File.txt")

}